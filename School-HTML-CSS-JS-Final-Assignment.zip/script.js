function suscribe(){
	if (confirm("Do you want to suscribe?")){
		alert("Thank you for suscribing!");
	}else{
		var b = 100; 
		alert("This is unacceptable! You shall be punished! ");
   	for (var a = 0; a < 600000000; a++){
			b = b * b * b * b * b * b * b * b;
		}
   	confirm("This page is unresponsive. Click 'Ok' to continue. ");
   	for (b; true; b = b * b * b){
			console.log(b);
		}
	}
}

function changebackgroundcolor(colorName) {
  document.body.style.background = colorName;
}

function changetextcolor(colorName) {
	document.body.style.color = colorName;
}